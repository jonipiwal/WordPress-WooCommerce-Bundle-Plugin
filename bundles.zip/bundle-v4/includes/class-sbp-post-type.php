<?php
/**
 * Admin Info Page: Bundle Info
 * Shortcode reference, usage guide, design settings, plugin details.
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

class SBP_Post_Type {

	public function __construct() {
		add_action( 'admin_menu',            array( $this, 'add_info_page' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_info_styles' ) );
		add_action( 'admin_init',            array( $this, 'register_settings' ) );
	}

	/* ------------------------------------------------------------------
	 * Register settings for typography customization
	 * ------------------------------------------------------------------ */
	public function register_settings() {
		register_setting( 'sbp_design_settings', 'sbp_accent_color',    array( 'default' => '#F5A623', 'sanitize_callback' => 'sanitize_hex_color' ) );
		register_setting( 'sbp_design_settings', 'sbp_item_bg',         array( 'default' => '#F3F5F7', 'sanitize_callback' => 'sanitize_hex_color' ) );
		register_setting( 'sbp_design_settings', 'sbp_text_color',      array( 'default' => '#121212', 'sanitize_callback' => 'sanitize_hex_color' ) );
		register_setting( 'sbp_design_settings', 'sbp_select_bg',       array( 'default' => '#1D1D1D', 'sanitize_callback' => 'sanitize_hex_color' ) );
		register_setting( 'sbp_design_settings', 'sbp_title_font_size', array( 'default' => '18',      'sanitize_callback' => 'absint' ) );
		register_setting( 'sbp_design_settings', 'sbp_desc_font_size',  array( 'default' => '14',      'sanitize_callback' => 'absint' ) );
		register_setting( 'sbp_design_settings', 'sbp_font_family',     array( 'default' => 'Manrope', 'sanitize_callback' => 'sanitize_text_field' ) );
	}

	/* ------------------------------------------------------------------
	 * Admin menu: single "Bundle Info" submenu under WooCommerce
	 * ------------------------------------------------------------------ */
	public function add_info_page() {
		add_submenu_page(
			'woocommerce',
			__( 'Bundle Info', 'wc-bundle' ),
			__( 'Bundle Info', 'wc-bundle' ),
			'manage_woocommerce',
			'sbp-plugin-info',
			array( $this, 'render_info_page' )
		);
	}

	public function enqueue_info_styles( $hook ) {
		if ( 'woocommerce_page_sbp-plugin-info' !== $hook ) { return; }
		wp_enqueue_style( 'sbp-gfont', 'https://fonts.googleapis.com/css2?family=Manrope:wght@400;600;700;800&display=swap', array(), null );
		$css = '
		.sbp-info-wrap { max-width: 960px; font-family: "Manrope", sans-serif; color: #1d1d1d; }
		.sbp-info-wrap h1 { font-size: 22px; font-weight: 800; margin-bottom: 4px; display: flex; align-items: center; gap: 10px; }
		.sbp-info-wrap .sbp-version { background: #f5a623; color: #fff; font-size: 11px; font-weight: 700; padding: 2px 8px; border-radius: 20px; vertical-align: middle; }
		.sbp-info-sub { color: #777; font-size: 13px; margin-bottom: 28px; }
		.sbp-info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 24px; }
		@media (max-width: 768px) { .sbp-info-grid { grid-template-columns: 1fr; } }
		.sbp-info-card { background: #fff; border: 1px solid #e5e5e5; border-top: 3px solid #f5a623; padding: 20px 22px; }
		.sbp-info-card h3 { font-size: 13px; font-weight: 800; text-transform: uppercase; letter-spacing: .04em; margin: 0 0 12px; color: #1d1d1d; }
		.sbp-info-card p, .sbp-info-card li { font-size: 13px; line-height: 1.7; color: #444; }
		.sbp-info-card ul { padding-left: 18px; margin: 0; }
		.sbp-info-card li { margin-bottom: 4px; }
		.sbp-sc-box { background: #1d1d1d; color: #f5a623; font-family: "Courier New", monospace; font-size: 13px; font-weight: 700; padding: 10px 14px; margin: 8px 0; display: block; letter-spacing: .02em; }
		.sbp-sc-desc { font-size: 12px; color: #666; margin: 0 0 12px; }
		.sbp-badge-row { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 8px; }
		.sbp-badge { background: #f3f5f7; border: 1px solid #e0e0e0; color: #333; font-size: 11px; font-weight: 600; padding: 4px 10px; }
		.sbp-author-box { background: #1d1d1d; color: #fff; padding: 16px 22px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 12px; margin-bottom: 24px; }
		.sbp-author-box strong { font-size: 13px; font-weight: 800; }
		.sbp-author-box a { color: #f5a623; text-decoration: none; font-size: 12px; }
		.sbp-author-box a:hover { text-decoration: underline; }
		.sbp-steps { counter-reset: sbp-step; list-style: none; padding: 0; margin: 0; }
		.sbp-steps li { counter-increment: sbp-step; display: flex; gap: 10px; align-items: flex-start; margin-bottom: 10px; font-size: 13px; color: #444; line-height: 1.6; }
		.sbp-steps li::before { content: counter(sbp-step); background: #f5a623; color: #fff; font-weight: 800; font-size: 11px; min-width: 20px; height: 20px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; margin-top: 2px; }
		/* Design Settings */
		.sbp-settings-section { margin-bottom: 24px; }
		.sbp-settings-section h2 { font-size: 15px; font-weight: 800; color: #1d1d1d; margin: 0 0 16px; padding-bottom: 8px; border-bottom: 2px solid #f5a623; }
		.sbp-settings-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; }
		.sbp-setting-field label { display: block; font-size: 12px; font-weight: 700; color: #555; margin-bottom: 6px; text-transform: uppercase; letter-spacing: .03em; }
		.sbp-setting-field input[type="color"] { width: 48px; height: 36px; border: 1px solid #ddd; border-radius: 4px; padding: 2px; cursor: pointer; }
		.sbp-setting-field input[type="number"],
		.sbp-setting-field select { font-family: "Manrope", sans-serif; font-size: 13px; border: 1px solid #ddd; border-radius: 4px; padding: 7px 10px; width: 100%; max-width: 160px; }
		.sbp-color-row { display: flex; align-items: center; gap: 10px; }
		.sbp-color-hex { font-size: 12px; color: #888; font-family: monospace; }
		.sbp-save-btn { background: #1d1d1d; color: #fff; border: none; border-radius: 4px; padding: 10px 24px; font-family: "Manrope", sans-serif; font-size: 13px; font-weight: 700; cursor: pointer; margin-top: 8px; }
		.sbp-save-btn:hover { background: #f5a623; }
		.sbp-settings-notice { background: #fff8ee; border-left: 3px solid #f5a623; padding: 10px 14px; font-size: 13px; color: #555; margin-bottom: 16px; }
		';
		wp_add_inline_style( 'wp-admin', $css );
	}

	/* ------------------------------------------------------------------
	 * Render info + design settings page
	 * ------------------------------------------------------------------ */
	public function render_info_page() {
		$plugin_version = defined( 'SBP_VERSION' ) ? SBP_VERSION : '3.0.0';

		/* Save settings */
		if ( isset( $_POST['sbp_save_design'] ) && check_admin_referer( 'sbp_design_save' ) ) {
			update_option( 'sbp_accent_color',    sanitize_hex_color( $_POST['sbp_accent_color']    ?? '#F5A623' ) );
			update_option( 'sbp_item_bg',         sanitize_hex_color( $_POST['sbp_item_bg']         ?? '#F3F5F7' ) );
			update_option( 'sbp_text_color',      sanitize_hex_color( $_POST['sbp_text_color']      ?? '#121212' ) );
			update_option( 'sbp_select_bg',       sanitize_hex_color( $_POST['sbp_select_bg']       ?? '#1D1D1D' ) );
			update_option( 'sbp_title_font_size', absint( $_POST['sbp_title_font_size']              ?? 18 ) );
			update_option( 'sbp_desc_font_size',  absint( $_POST['sbp_desc_font_size']               ?? 14 ) );
			update_option( 'sbp_font_family',     sanitize_text_field( $_POST['sbp_font_family']     ?? 'Manrope' ) );
			echo '<div class="notice notice-success is-dismissible"><p><strong>Design settings saved.</strong></p></div>';
		}

		$accent      = get_option( 'sbp_accent_color',    '#F5A623' );
		$item_bg     = get_option( 'sbp_item_bg',         '#F3F5F7' );
		$text_color  = get_option( 'sbp_text_color',      '#121212' );
		$select_bg   = get_option( 'sbp_select_bg',       '#1D1D1D' );
		$title_fs    = get_option( 'sbp_title_font_size', 18 );
		$desc_fs     = get_option( 'sbp_desc_font_size',  14 );
		$font_family = get_option( 'sbp_font_family',     'Manrope' );
		?>
		<div class="wrap sbp-info-wrap">
			<h1>
				WooCommerce Bundle
				<span class="sbp-version">v<?php echo esc_html( $plugin_version ); ?></span>
			</h1>
			<p class="sbp-info-sub">Softbourne Technologies &mdash; Complete bundle product solution for WooCommerce</p>

			<div class="sbp-info-grid">

				<!-- SHORTCODES -->
				<div class="sbp-info-card">
					<h3>Shortcodes</h3>
					<code class="sbp-sc-box">[wc_bundle]</code>
					<p class="sbp-sc-desc">Display the bundle on the current product page.</p>
					<code class="sbp-sc-box">[wc_bundle id="123"]</code>
					<p class="sbp-sc-desc">Display the bundle for a specific product ID on any page.</p>
					<code class="sbp-sc-box">[setwear_bundle]</code>
					<p class="sbp-sc-desc">Backward-compatible alias — produces identical output.</p>
				</div>

				<!-- HOW TO USE -->
				<div class="sbp-info-card">
					<h3>How to Use</h3>
					<ol class="sbp-steps">
						<li>Go to WooCommerce &rarr; Products and open any product.</li>
						<li>In the <strong>Bundle Product</strong> meta-box, toggle <strong>Enable</strong>.</li>
						<li>Click <strong>Add Bundle Item</strong> and set the title, image, sizes, and colors.</li>
						<li>Save the product.</li>
						<li>Paste <code>[wc_bundle]</code> into the product description or any block.</li>
						<li><strong>Set a Regular Price</strong> on the product — this shows as the &ldquo;purchased separately&rdquo; value in the bundle savings line.</li>
						<li><strong>Set a Sale Price</strong> on the product — this becomes the bold &ldquo;get it for just&rdquo; price. If no sale price is set, the regular price is shown for both.</li>
					</ol>
				</div>

				<!-- FEATURES -->
				<div class="sbp-info-card">
					<h3>Features</h3>
					<ul>
						<li>Drag-and-drop item reordering</li>
						<li>Rich text description (Bold, Italic, Color)</li>
						<li>Per-item Size &amp; Color variants (dropdowns)</li>
						<li>Media Library image upload</li>
						<li>Read More / Read Less toggle on frontend</li>
						<li>Bundle details automatically saved with orders</li>
						<li>Bundle contents table visible on admin order page</li>
						<li>Responsive design — mobile friendly</li>
					</ul>
				</div>

				<!-- ORDER INFO -->
				<div class="sbp-info-card">
					<h3>Order Info</h3>
					<p>When a customer orders a bundle product, the following data is automatically saved with the order:</p>
					<div class="sbp-badge-row">
						<span class="sbp-badge">Bundle Item Titles</span>
						<span class="sbp-badge">Available Sizes</span>
						<span class="sbp-badge">Available Colors</span>
						<span class="sbp-badge">Item Count</span>
					</div>
					<p style="margin-top:12px;">View in Admin &rarr; Orders &rarr; Order detail under <strong>Bundle Contents</strong>.</p>
				</div>

				<!-- PLUGIN INFO -->
				<div class="sbp-info-card">
					<h3>Plugin Info</h3>
					<ul>
						<li><strong>Version:</strong> <?php echo esc_html( $plugin_version ); ?></li>
						<li><strong>Requires WordPress:</strong> 5.8+</li>
						<li><strong>Requires PHP:</strong> 7.4+</li>
						<li><strong>Requires WooCommerce:</strong> 5.0+</li>
						<li><strong>Text Domain:</strong> wc-bundle</li>
						<li><strong>License:</strong> GPL-2.0+</li>
					</ul>
				</div>

			</div><!-- /.sbp-info-grid -->

			<!-- DESIGN SETTINGS -->
			<div class="sbp-settings-section">
				<h2>Design &amp; Typography Settings</h2>
				<p class="sbp-settings-notice">
					These settings override the default styles on the frontend bundle display. Leave unchanged to use defaults.
				</p>
				<form method="post">
					<?php wp_nonce_field( 'sbp_design_save' ); ?>
					<div class="sbp-settings-grid">

						<div class="sbp-setting-field">
							<label for="sbp_font_family">Font Family</label>
							<select name="sbp_font_family" id="sbp_font_family">
								<?php
								$fonts = array( 'Manrope', 'Inter', 'Poppins', 'Lato', 'Roboto', 'Open Sans', 'Nunito', 'DM Sans' );
								foreach ( $fonts as $f ) {
									echo '<option value="' . esc_attr( $f ) . '" ' . selected( $font_family, $f, false ) . '>' . esc_html( $f ) . '</option>';
								}
								?>
							</select>
						</div>

						<div class="sbp-setting-field">
							<label for="sbp_title_font_size">Item Title Font Size (px)</label>
							<input type="number" id="sbp_title_font_size" name="sbp_title_font_size" value="<?php echo esc_attr( $title_fs ); ?>" min="12" max="36" step="1">
						</div>

						<div class="sbp-setting-field">
							<label for="sbp_desc_font_size">Description Font Size (px)</label>
							<input type="number" id="sbp_desc_font_size" name="sbp_desc_font_size" value="<?php echo esc_attr( $desc_fs ); ?>" min="10" max="24" step="1">
						</div>

						<div class="sbp-setting-field">
							<label>Accent Color</label>
							<div class="sbp-color-row">
								<input type="color" name="sbp_accent_color" value="<?php echo esc_attr( $accent ); ?>">
								<span class="sbp-color-hex"><?php echo esc_html( $accent ); ?></span>
							</div>
						</div>

						<div class="sbp-setting-field">
							<label>Item Background Color</label>
							<div class="sbp-color-row">
								<input type="color" name="sbp_item_bg" value="<?php echo esc_attr( $item_bg ); ?>">
								<span class="sbp-color-hex"><?php echo esc_html( $item_bg ); ?></span>
							</div>
						</div>

						<div class="sbp-setting-field">
							<label>Text Color</label>
							<div class="sbp-color-row">
								<input type="color" name="sbp_text_color" value="<?php echo esc_attr( $text_color ); ?>">
								<span class="sbp-color-hex"><?php echo esc_html( $text_color ); ?></span>
							</div>
						</div>

						<div class="sbp-setting-field">
							<label>Select Button Background</label>
							<div class="sbp-color-row">
								<input type="color" name="sbp_select_bg" value="<?php echo esc_attr( $select_bg ); ?>">
								<span class="sbp-color-hex"><?php echo esc_html( $select_bg ); ?></span>
							</div>
						</div>

					</div>
					<br>
					<button type="submit" name="sbp_save_design" class="sbp-save-btn">Save Design Settings</button>
				</form>
			</div>

			<div class="sbp-author-box">
				<div>
					<strong>Softbourne Technologies</strong><br>
					<span style="font-size:12px;color:#aaa;">WooCommerce Customization &amp; Plugin Development</span>
				</div>
				<div>
					<a href="https://softbourne.com" target="_blank">softbourne.com</a>
				</div>
			</div>

		</div>
		<?php
	}
}
