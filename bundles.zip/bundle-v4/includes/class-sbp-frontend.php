<?php
/**
 * Frontend: Shortcode [wc_bundle]
 * v3.0 – Equal cards, Read More fix, selections saved to cart/order
 *
 * Features:
 * - [wc_bundle] shortcode — display on product page
 * - Size/color selections saved into cart item data
 * - Bundle contents + selected variants shown in cart, mini-cart, and checkout
 * - Full bundle details with selected sizes/colors in order admin
 * - Bundle contents shown in email
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

class SBP_Frontend {

	public function __construct() {
		add_shortcode( 'wc_bundle',      array( $this, 'render_bundle' ) );
		add_shortcode( 'setwear_bundle', array( $this, 'render_bundle' ) );

		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue' ) );

		/* ── Save selections from form POST into cart item ── */
		add_filter( 'woocommerce_add_cart_item_data',     array( $this, 'save_selections_to_cart' ), 10, 3 );

		/* ── Display bundle info in cart/checkout ── */
		add_filter( 'woocommerce_cart_item_name',         array( $this, 'display_in_cart' ), 20, 3 );

		/* ── Pass to order on checkout ── */
		add_action( 'woocommerce_checkout_create_order_line_item', array( $this, 'save_to_order_item' ), 10, 4 );

		/* ── Admin order page display ── */
		add_action( 'woocommerce_after_order_itemmeta',   array( $this, 'display_in_admin_order' ), 20, 3 );

		/* ── Frontend order detail / my-account / email ── */
		add_action( 'woocommerce_order_item_meta_end',    array( $this, 'display_in_frontend_order' ), 20, 3 );

		/* ── Hide raw JSON from order meta display ── */
		add_filter( 'woocommerce_hidden_order_itemmeta',  array( $this, 'hide_raw_meta' ) );
	}

	/* ================================================================
	   ENQUEUE
	   ================================================================ */
	public function enqueue() {
		wp_enqueue_style(
			'sbp-frontend',
			SBP_URL . 'assets/css/frontend.css',
			array(),
			SBP_VERSION
		);
		wp_enqueue_script(
			'sbp-frontend',
			SBP_URL . 'assets/js/frontend.js',
			array( 'jquery' ),
			SBP_VERSION,
			true
		);

		/* Override CSS variables and font from saved design settings */
		$accent      = get_option( 'sbp_accent_color',    '#F5A623' );
		$item_bg     = get_option( 'sbp_item_bg',         '#F3F5F7' );
		$text_color  = get_option( 'sbp_text_color',      '#121212' );
		$select_bg   = get_option( 'sbp_select_bg',       '#1D1D1D' );
		$title_fs    = absint( get_option( 'sbp_title_font_size', 18 ) );
		$desc_fs     = absint( get_option( 'sbp_desc_font_size',  14 ) );
		$font_family = sanitize_text_field( get_option( 'sbp_font_family', 'Manrope' ) );

		$dynamic_css = "
.sbp-bundle-section {
	--sbp-accent:    {$accent};
	--sbp-item-bg:   {$item_bg};
	--sbp-text:      {$text_color};
	--sbp-select-bg: {$select_bg};
	font-family: '{$font_family}', sans-serif;
}
.sbp-bundle-section .sbp-bundle-item .sbp-bundle-item-title {
	font-size: {$title_fs}px !important;
	font-family: '{$font_family}', sans-serif !important;
}
.sbp-bundle-section .sbp-bundle-item .sbp-bundle-item-desc {
	font-size: {$desc_fs}px;
	font-family: '{$font_family}', sans-serif;
}
.sbp-bundle-section .sbp-select { background-color: {$select_bg} !important; }
.sbp-bundle-section .sbp-select option { background: {$select_bg}; }
		";
		wp_add_inline_style( 'sbp-frontend', $dynamic_css );
	}

	/* ================================================================
	   SHORTCODE RENDERER
	   ================================================================ */
	public function render_bundle( $atts ) {
		$atts = shortcode_atts( array( 'id' => get_the_ID() ), $atts, 'wc_bundle' );
		$pid  = absint( $atts['id'] );

		$enabled = get_post_meta( $pid, '_sbp_bundle_enabled', true );
		if ( ! $enabled ) { return ''; }

		$items = get_post_meta( $pid, '_sbp_bundle_items', true );
		if ( ! is_array( $items ) || empty( $items ) ) { return ''; }

		ob_start();
		?>
		<div class="sbp-bundle-section">
			<div class="sbp-bundle-box">
				<div class="sbp-bundle-header">
					<h3 class="sbp-bundle-title">What's in this Bundle</h3>
				</div>
				<div class="sbp-bundle-list">
					<?php foreach ( $items as $item ) : ?>
					<div class="sbp-bundle-item">

						<div class="sbp-bundle-img">
							<?php if ( ! empty( $item['image_url'] ) ) : ?>
								<img src="<?php echo esc_url( $item['image_url'] ); ?>"
									alt="<?php echo esc_attr( $item['title'] ); ?>" loading="lazy">
							<?php else : ?>
								<span class="sbp-no-img">📦</span>
							<?php endif; ?>
						</div>

						<div class="sbp-bundle-info">
							<h4 class="sbp-bundle-item-title"><?php echo esc_html( $item['title'] ); ?></h4>

							<?php if ( ! empty( $item['desc'] ) ) : ?>
								<p class="sbp-bundle-item-desc"><?php echo wp_kses_post( $item['desc'] ); ?></p>
								<a href="#" class="sbp-read-more">Read More</a>
							<?php else : ?>
								<!-- No desc: spacer only -->
								<div class="sbp-info-spacer"></div>
							<?php endif; ?>

							<?php
							$has_selects = ( ! empty( $item['has_sizes'] ) && ! empty( $item['sizes'] ) )
							           || ( ! empty( $item['has_colors'] ) && ! empty( $item['colors'] ) );
							?>
							<?php if ( $has_selects ) : ?>
							<div class="sbp-bundle-selects">
								<?php if ( ! empty( $item['has_sizes'] ) && ! empty( $item['sizes'] ) ) : ?>
								<div class="sbp-select-wrap">
									<select class="sbp-select" aria-label="Select Size">
										<option value="">Select Size</option>
										<?php foreach ( $item['sizes'] as $sz ) : ?>
											<option value="<?php echo esc_attr( $sz ); ?>"><?php echo esc_html( $sz ); ?></option>
										<?php endforeach; ?>
									</select>
									<span class="sbp-select-arrow">▾</span>
								</div>
								<?php endif; ?>

								<?php if ( ! empty( $item['has_colors'] ) && ! empty( $item['colors'] ) ) : ?>
								<div class="sbp-select-wrap">
									<select class="sbp-select" aria-label="Select Color">
										<option value="">Select Color</option>
										<?php foreach ( $item['colors'] as $col ) : ?>
											<option value="<?php echo esc_attr( $col ); ?>"><?php echo esc_html( $col ); ?></option>
										<?php endforeach; ?>
									</select>
									<span class="sbp-select-arrow">▾</span>
								</div>
								<?php endif; ?>
							</div>
							<?php endif; ?>

						</div><!-- /.sbp-bundle-info -->
					</div><!-- /.sbp-bundle-item -->
					<?php endforeach; ?>
				</div><!-- /.sbp-bundle-list -->

				<?php
				/* ── Bundle savings price line ── */
				$product = wc_get_product( $pid );
				if ( $product ) {
					$regular_price = (float) $product->get_regular_price();
					$sale_price    = (float) $product->get_sale_price();
					$has_sale      = $product->is_on_sale() && $sale_price > 0;
					if ( $regular_price > 0 ) :
				?>
				<div class="sbp-price-line">
					<p class="sbp-price-text">
						Purchased separately, this professional work gear loadout would cost
						<span class="sbp-price-regular"><?php echo wp_kses_post( wc_price( $regular_price ) ); ?></span>.
						Lock in your complete setup and get job-ready for just
						<strong class="sbp-price-sale"><?php echo wp_kses_post( $has_sale ? wc_price( $sale_price ) : wc_price( $regular_price ) ); ?></strong>.
					</p>
				</div>
				<?php endif; } ?>

			</div><!-- /.sbp-bundle-box -->
		</div><!-- /.sbp-bundle-section -->
		<?php
		return ob_get_clean();
	}

	/* ================================================================
	   SAVE SELECTIONS INTO CART ITEM DATA
	   Called when product added to cart (via form POST)
	   ================================================================ */
	public function save_selections_to_cart( $cart_item_data, $product_id, $variation_id ) {
		$enabled = get_post_meta( $product_id, '_sbp_bundle_enabled', true );
		if ( ! $enabled ) { return $cart_item_data; }

		/* Read selections from POST */
		if ( ! empty( $_POST['_sbp_selections_json'] ) ) {
			$decoded = json_decode( wp_unslash( $_POST['_sbp_selections_json'] ), true );
			if ( is_array( $decoded ) ) {
				$cart_item_data['_sbp_selections'] = $decoded;
			}
		}

		/* Also pull bundle items from DB so we always have titles */
		$bundle_items = get_post_meta( $product_id, '_sbp_bundle_items', true );
		if ( is_array( $bundle_items ) && ! empty( $bundle_items ) ) {
			$cart_item_data['_sbp_bundle_items'] = $bundle_items;
		}

		/* Unique key so same product can be added twice with diff selections */
		if ( ! empty( $cart_item_data['_sbp_selections'] ) ) {
			$cart_item_data['unique_key'] = md5( microtime() . rand() );
		}

		return $cart_item_data;
	}

	/* ================================================================
	   DISPLAY BUNDLE INFO IN CART ITEM NAME
	   Works for cart page, mini-cart, and checkout review
	   ================================================================ */
	public function display_in_cart( $name, $cart_item, $cart_item_key ) {
		$bundle_items = isset( $cart_item['_sbp_bundle_items'] ) ? $cart_item['_sbp_bundle_items'] : array();
		if ( empty( $bundle_items ) ) {
			/* Fallback: load from product meta */
			$pid          = $cart_item['product_id'];
			$bundle_items = get_post_meta( $pid, '_sbp_bundle_items', true );
		}
		if ( ! is_array( $bundle_items ) || empty( $bundle_items ) ) {
			return $name;
		}

		$selections = isset( $cart_item['_sbp_selections'] ) ? $cart_item['_sbp_selections'] : array();

		/* Build lookup: index => selection */
		$sel_map = array();
		foreach ( $selections as $sel ) {
			$sel_map[ intval( $sel['index'] ) ] = $sel;
		}

		ob_start();
		?>
		<div class="sbp-cart-bundle-info">
			<span class="sbp-cart-bundle-title">📦 Bundle Contents</span>
			<ul>
				<?php foreach ( $bundle_items as $idx => $bi ) :
					if ( empty( $bi['title'] ) ) continue;
					$sel   = isset( $sel_map[ $idx ] ) ? $sel_map[ $idx ] : array();
					$size  = ! empty( $sel['size'] )  ? trim( $sel['size'] )  : '';
					$color = ! empty( $sel['color'] ) ? trim( $sel['color'] ) : '';
					$meta  = array();
					if ( $size )  $meta[] = 'Size: ' . esc_html( $size );
					if ( $color ) $meta[] = 'Color: ' . esc_html( $color );
				?>
				<li>
					<span class="sbp-cart-item-name"><?php echo esc_html( $bi['title'] ); ?></span>
					<?php if ( $size ) : ?>
						<span class="sbp-cart-item-variants" data-sbp-variant="size">Size: <span class="sbp-variant-val"><?php echo esc_html( $size ); ?></span></span>
					<?php endif; ?>
					<?php if ( $color ) : ?>
						<span class="sbp-cart-item-variants" data-sbp-variant="color">Color: <span class="sbp-variant-val"><?php echo esc_html( $color ); ?></span></span>
					<?php endif; ?>
				</li>
				<?php endforeach; ?>
			</ul>
		</div>
		<?php
		$info = ob_get_clean();
		return $name . $info;
	}

	/* ================================================================
	   SAVE TO ORDER LINE ITEM ON CHECKOUT
	   ================================================================ */
	public function save_to_order_item( $item, $cart_item_key, $values, $order ) {
		$bundle_items = isset( $values['_sbp_bundle_items'] ) ? $values['_sbp_bundle_items'] : array();
		if ( empty( $bundle_items ) ) {
			$bundle_items = get_post_meta( $values['product_id'], '_sbp_bundle_items', true );
		}
		if ( ! is_array( $bundle_items ) || empty( $bundle_items ) ) { return; }

		$selections = isset( $values['_sbp_selections'] ) ? $values['_sbp_selections'] : array();

		/* Build selection map */
		$sel_map = array();
		foreach ( $selections as $sel ) {
			$sel_map[ intval( $sel['index'] ) ] = $sel;
		}

		/* Prepare structured data for admin display */
		$structured = array();
		$summary    = array();

		foreach ( $bundle_items as $idx => $bi ) {
			if ( empty( $bi['title'] ) ) { continue; }
			$sel   = isset( $sel_map[ $idx ] ) ? $sel_map[ $idx ] : array();
			$size  = ! empty( $sel['size'] )  ? trim( $sel['size'] )  : '';
			$color = ! empty( $sel['color'] ) ? trim( $sel['color'] ) : '';

			$row = array(
				'title'      => $bi['title'],
				'size'       => $size,
				'color'      => $color,
				'has_sizes'  => ! empty( $bi['has_sizes'] ),
				'has_colors' => ! empty( $bi['has_colors'] ),
				'image_url'  => ! empty( $bi['image_url'] ) ? $bi['image_url'] : '',
			);
			$structured[] = $row;

			/* Human readable summary */
			$line = ( $idx + 1 ) . '. ' . $bi['title'];
			if ( $size )  { $line .= ' · Size: ' . $size; }
			if ( $color ) { $line .= ' · Color: ' . $color; }
			$summary[] = $line;
		}

		/* Store JSON (hidden — used for rich display) */
		$item->add_meta_data( '_sbp_bundle_data_json', wp_json_encode( $structured ), true );

		/* Store readable summary (visible label) */
		if ( ! empty( $summary ) ) {
			$item->add_meta_data( 'Bundle Contents', implode( "\n", $summary ), true );
		}
	}

	/* ================================================================
	   ADMIN ORDER PAGE — RICH TABLE DISPLAY
	   ================================================================ */
	public function display_in_admin_order( $item_id, $item, $product ) {
		if ( ! $item instanceof WC_Order_Item_Product ) { return; }

		$json = $item->get_meta( '_sbp_bundle_data_json' );
		if ( ! $json ) { return; }

		$rows = json_decode( $json, true );
		if ( ! is_array( $rows ) || empty( $rows ) ) { return; }

		echo '<div style="margin:10px 0 16px;padding:12px 14px;background:#fff8ee;border-left:3px solid #f5a623;font-size:12px;font-family:sans-serif;">';
		echo '<strong style="display:block;margin-bottom:8px;color:#1d1d1d;font-size:13px;">📦 Bundle Contents (' . count( $rows ) . ' items)</strong>';
		echo '<table style="width:100%;border-collapse:collapse;">';
		echo '<thead><tr style="border-bottom:2px solid #f0d8a0;">';
		echo '<th style="text-align:left;padding:5px 8px;color:#666;font-weight:600;">#</th>';
		echo '<th style="text-align:left;padding:5px 8px;color:#666;font-weight:600;">Item</th>';
		echo '<th style="text-align:left;padding:5px 8px;color:#666;font-weight:600;">Size</th>';
		echo '<th style="text-align:left;padding:5px 8px;color:#666;font-weight:600;">Color</th>';
		echo '</tr></thead>';
		echo '<tbody>';
		foreach ( $rows as $i => $row ) {
			$title  = ! empty( $row['title'] ) ? esc_html( $row['title'] ) : '—';
			$size   = ! empty( $row['size'] )  ? esc_html( $row['size'] )  : ( $row['has_sizes']  ? '<em style="color:#aaa">Not selected</em>' : '—' );
			$color  = ! empty( $row['color'] ) ? esc_html( $row['color'] ) : ( $row['has_colors'] ? '<em style="color:#aaa">Not selected</em>' : '—' );
			$bg     = $i % 2 === 0 ? '#fffdf7' : '#fff';
			echo '<tr style="background:' . $bg . ';border-bottom:1px solid #f5e9cc;">';
			echo '<td style="padding:5px 8px;color:#999;">' . ( $i + 1 ) . '</td>';
			echo '<td style="padding:5px 8px;font-weight:600;color:#121212;">' . $title . '</td>';
			echo '<td style="padding:5px 8px;color:#555;">' . $size . '</td>';
			echo '<td style="padding:5px 8px;color:#555;">' . $color . '</td>';
			echo '</tr>';
		}
		echo '</tbody></table>';
		echo '</div>';
	}

	/* ================================================================
	   FRONTEND ORDER / MY-ACCOUNT / EMAIL DISPLAY
	   ================================================================ */
	public function display_in_frontend_order( $item_id, $item, $order ) {
		if ( ! $item instanceof WC_Order_Item_Product ) { return; }

		$json = $item->get_meta( '_sbp_bundle_data_json' );
		if ( ! $json ) { return; }

		$rows = json_decode( $json, true );
		if ( ! is_array( $rows ) || empty( $rows ) ) { return; }

		echo '<div style="margin:10px 0 0;font-family:sans-serif;font-size:13px;">';
		echo '<strong style="display:block;margin-bottom:6px;color:#121212;">📦 Bundle Contents</strong>';
		echo '<ul style="margin:0;padding:0;list-style:none;">';
		foreach ( $rows as $i => $row ) {
			if ( empty( $row['title'] ) ) { continue; }
			$meta = array();
			if ( ! empty( $row['size'] ) )  { $meta[] = 'Size: ' . esc_html( $row['size'] ); }
			if ( ! empty( $row['color'] ) ) { $meta[] = 'Color: ' . esc_html( $row['color'] ); }
			echo '<li style="padding:3px 0 3px 18px;position:relative;border-bottom:1px solid #f5f5f5;">';
			echo '<span style="position:absolute;left:0;color:#f5a623;font-size:14px;">•</span>';
			echo '<strong>' . esc_html( $row['title'] ) . '</strong>';
			if ( $meta ) {
				echo ' <span style="color:#888;font-size:12px;">(' . implode( ', ', $meta ) . ')</span>';
			}
			echo '</li>';
		}
		echo '</ul>';
		echo '</div>';
	}

	/* ================================================================
	   HIDE RAW META FROM WC ORDER DISPLAY
	   ================================================================ */
	public function hide_raw_meta( $hidden ) {
		$hidden[] = '_sbp_bundle_data_json';
		$hidden[] = '_sbp_bundle_items';
		$hidden[] = '_sbp_selections';
		return $hidden;
	}
}
