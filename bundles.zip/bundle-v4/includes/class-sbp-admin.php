<?php
/**
 * Admin: Bundle meta-box – professional UI, repeater, rich description editor.
 * Author: Softbourne Technologies | https://softbourne.com
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

class SBP_Admin {

	public function __construct() {
		add_action( 'add_meta_boxes',        array( $this, 'add_meta_box' ) );
		add_action( 'save_post_product',     array( $this, 'save_meta' ), 10, 2 );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue' ) );

		// Save bundle details with order
		add_action( 'woocommerce_checkout_create_order_line_item', array( $this, 'add_bundle_data_to_order_item' ), 10, 4 );
		add_filter( 'woocommerce_order_item_display_meta_key',     array( $this, 'rename_order_meta_key' ), 10, 3 );
		add_filter( 'woocommerce_hidden_order_itemmeta',           array( $this, 'hide_raw_bundle_meta' ) );
		add_action( 'woocommerce_after_order_itemmeta',            array( $this, 'display_bundle_items_in_order' ), 10, 3 );
	}

	public function enqueue( $hook ) {
		global $post;
		if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) { return; }
		if ( ! $post || 'product' !== $post->post_type ) { return; }

		wp_enqueue_media();
		wp_enqueue_style( 'sbp-gfont', 'https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&display=swap', array(), null );
		wp_enqueue_style(  'sbp-admin', SBP_URL . 'assets/css/admin.css',  array(), SBP_VERSION );
		wp_enqueue_script( 'sbp-admin', SBP_URL . 'assets/js/admin.js', array( 'jquery', 'jquery-ui-sortable' ), SBP_VERSION, true );

		wp_localize_script( 'sbp-admin', 'SBP', array(
			'nonce'       => wp_create_nonce( 'sbp_save' ),
			'chooseImage' => __( 'Select Image', 'setwear-bundle' ),
			'useImage'    => __( 'Use This Image', 'setwear-bundle' ),
		) );
	}

	public function add_meta_box() {
		add_meta_box( 'sbp_bundle_box', 'Bundle Product', array( $this, 'render_meta_box' ), 'product', 'normal', 'high' );
	}

	public function render_meta_box( $post ) {
		wp_nonce_field( 'sbp_save', 'sbp_nonce' );
		$enabled = get_post_meta( $post->ID, '_sbp_bundle_enabled', true );
		$items   = get_post_meta( $post->ID, '_sbp_bundle_items', true );
		if ( ! is_array( $items ) ) { $items = array(); }
		?>
		<div class="sbp-wrap">
			<div class="sbp-topbar">
				<div class="sbp-topbar-left">
					<svg class="sbp-topbar-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>
					<div>
						<div class="sbp-topbar-title">Bundle Product Configuration</div>
						<div class="sbp-topbar-sub">Manage bundle items displayed on the product page</div>
					</div>
				</div>
				<label class="sbp-switch" title="Toggle bundle visibility on frontend">
					<input type="checkbox" id="sbp_bundle_enabled" name="sbp_bundle_enabled" value="1" <?php checked( $enabled, '1' ); ?>>
					<span class="sbp-switch-track">
						<span class="sbp-switch-thumb"></span>
					</span>
					<span class="sbp-switch-label" id="sbp_switch_label"><?php echo $enabled ? 'Enabled' : 'Disabled'; ?></span>
				</label>
			</div>

			<div id="sbp_bundle_builder" class="sbp-bundle-builder <?php echo $enabled ? '' : 'sbp-hidden'; ?>">
				<div class="sbp-builder-toolbar">
					<div class="sbp-toolbar-info">
						<span class="sbp-count-badge" id="sbp_item_count"><?php echo count( $items ); ?></span>
						<span class="sbp-toolbar-text">Items &nbsp;&middot;&nbsp; Drag rows to reorder</span>
					</div>
					<button type="button" id="sbp_add_item" class="sbp-btn-primary">
						<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
						Add Bundle Item
					</button>
				</div>

				<div id="sbp_items_wrap" class="sbp-items-wrap">
					<?php foreach ( $items as $i => $item ) : $this->render_item_row( $i, $item ); endforeach; ?>
				</div>

				<script type="text/template" id="sbp_item_template"><?php $this->render_item_row( '__INDEX__', array() ); ?></script>

				<div class="sbp-builder-footer">
					<button type="button" class="sbp-btn-ghost sbp-add-item-alias">
						<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
						Add Another Item
					</button>
				</div>
			</div>

			<div id="sbp_disabled_notice" class="sbp-disabled-notice <?php echo $enabled ? 'sbp-hidden' : ''; ?>">
				<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
				Enable the toggle above to configure bundle items. The bundle section will be hidden on the frontend until activated.
			</div>
		</div>
		<?php
	}

	private function render_item_row( $i, $item ) {
		$image_id   = isset( $item['image_id'] )   ? $item['image_id']   : '';
		$image_url  = isset( $item['image_url'] )  ? $item['image_url']  : '';
		$title      = isset( $item['title'] )      ? $item['title']      : '';
		$desc       = isset( $item['desc'] )       ? $item['desc']       : '';
		$has_sizes  = isset( $item['has_sizes'] )  ? $item['has_sizes']  : '';
		$has_colors = isset( $item['has_colors'] ) ? $item['has_colors'] : '';
		$sizes      = ( isset( $item['sizes'] )  && is_array( $item['sizes'] )  && count( $item['sizes'] )  ) ? $item['sizes']  : array( '' );
		$colors     = ( isset( $item['colors'] ) && is_array( $item['colors'] ) && count( $item['colors'] ) ) ? $item['colors'] : array( '' );
		$display_num = is_numeric( $i ) ? $i + 1 : '–';
		?>
		<div class="sbp-item-row" data-index="<?php echo esc_attr( $i ); ?>">
			<div class="sbp-row-header">
				<button type="button" class="sbp-drag-handle" title="Drag to reorder">
					<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><circle cx="9" cy="5" r="1.5"/><circle cx="9" cy="12" r="1.5"/><circle cx="9" cy="19" r="1.5"/><circle cx="15" cy="5" r="1.5"/><circle cx="15" cy="12" r="1.5"/><circle cx="15" cy="19" r="1.5"/></svg>
				</button>
				<span class="sbp-row-badge">Item <span class="sbp-item-num"><?php echo esc_html( $display_num ); ?></span></span>
				<span class="sbp-row-preview"><?php echo $title ? esc_html( mb_strimwidth( $title, 0, 50, '…' ) ) : '<em>Untitled item</em>'; ?></span>
				<div class="sbp-row-acts">
					<button type="button" class="sbp-collapse-row" title="Collapse">
						<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="18 15 12 9 6 15"/></svg>
					</button>
					<button type="button" class="sbp-remove-item" title="Delete item">
						<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/></svg>
						Remove
					</button>
				</div>
			</div>

			<div class="sbp-row-body">
				<div class="sbp-row-grid">
					<div class="sbp-col-img">
						<div class="sbp-field-label">Item Image</div>
						<div class="sbp-img-zone <?php echo $image_url ? 'has-img' : ''; ?>">
							<div class="sbp-img-thumb">
								<?php if ( $image_url ) : ?>
									<img src="<?php echo esc_url( $image_url ); ?>" alt="">
								<?php else : ?>
									<div class="sbp-img-empty">
										<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" opacity=".35"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
									</div>
								<?php endif; ?>
							</div>
							<input type="hidden" name="sbp_items[<?php echo esc_attr( $i ); ?>][image_id]"  class="sbp-image-id"  value="<?php echo esc_attr( $image_id ); ?>">
							<input type="hidden" name="sbp_items[<?php echo esc_attr( $i ); ?>][image_url]" class="sbp-image-url" value="<?php echo esc_url( $image_url ); ?>">
							<button type="button" class="sbp-choose-image sbp-img-btn"><?php echo $image_url ? 'Change Image' : 'Upload Image'; ?></button>
							<?php if ( $image_url ) : ?><button type="button" class="sbp-remove-image sbp-img-remove">Remove</button><?php endif; ?>
						</div>
					</div>

					<div class="sbp-col-fields">
						<div class="sbp-field-group">
							<label class="sbp-field-label">Item Title <span class="sbp-req">*</span></label>
							<input type="text" name="sbp_items[<?php echo esc_attr( $i ); ?>][title]" class="sbp-input sbp-title-input" value="<?php echo esc_attr( $title ); ?>" placeholder="e.g. Pro Leather Work Gloves">
						</div>

						<div class="sbp-field-group">
							<label class="sbp-field-label">Item Description</label>
							<div class="sbp-editor-wrap">
								<div class="sbp-editor-bar">
									<button type="button" class="sbp-fmt" data-cmd="bold"        title="Bold"><strong>B</strong></button>
									<button type="button" class="sbp-fmt" data-cmd="italic"      title="Italic"><em>I</em></button>
									<button type="button" class="sbp-fmt" data-cmd="underline"   title="Underline"><span style="text-decoration:underline">U</span></button>
									<span class="sbp-sep"></span>
									<button type="button" class="sbp-fmt sbp-color-btn" data-cmd="foreColor" data-val="#f5a623" title="Orange" style="--cc:#f5a623">A</button>
									<button type="button" class="sbp-fmt sbp-color-btn" data-cmd="foreColor" data-val="#121212" title="Dark"   style="--cc:#121212">A</button>
									<button type="button" class="sbp-fmt sbp-color-btn" data-cmd="foreColor" data-val="#d63638" title="Red"    style="--cc:#d63638">A</button>
									<span class="sbp-sep"></span>
									<button type="button" class="sbp-fmt sbp-clear-fmt" data-cmd="removeFormat" title="Clear Formatting">
										<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="4" y1="7" x2="20" y2="7"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/><line x1="5" y1="7" x2="19" y2="19"/></svg>
									</button>
								</div>
								<div class="sbp-rich-editor" contenteditable="true" data-placeholder="Enter a short description for this bundle item…"><?php echo wp_kses_post( $desc ); ?></div>
								<input type="hidden" name="sbp_items[<?php echo esc_attr( $i ); ?>][desc]" class="sbp-desc-hidden" value="<?php echo esc_attr( $desc ); ?>">
							</div>
						</div>
					</div>
				</div>

				<div class="sbp-variants">
					<div class="sbp-variant-col">
						<label class="sbp-check-label">
							<input type="checkbox" name="sbp_items[<?php echo esc_attr( $i ); ?>][has_sizes]" class="sbp-has-sizes" value="1" <?php checked( $has_sizes, '1' ); ?>>
							<span class="sbp-chk-box"></span>
							<span>Sizes available for this item?</span>
						</label>
						<div class="sbp-variant-body sbp-sizes-wrap <?php echo $has_sizes ? '' : 'sbp-hidden'; ?>">
							<div class="sbp-variant-title">Available Sizes <small>— one per field</small></div>
							<div class="sbp-sub-rows sbp-size-rows">
								<?php foreach ( $sizes as $sz ) : ?>
								<div class="sbp-sub-row">
									<input type="text" name="sbp_items[<?php echo esc_attr( $i ); ?>][sizes][]" class="sbp-input sbp-sub-input" value="<?php echo esc_attr( $sz ); ?>" placeholder="e.g. S">
									<button type="button" class="sbp-del-sub" title="Remove"><svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
								</div>
								<?php endforeach; ?>
							</div>
							<button type="button" class="sbp-add-sub sbp-add-size">+ Add Size</button>
						</div>
					</div>

					<div class="sbp-variant-col">
						<label class="sbp-check-label">
							<input type="checkbox" name="sbp_items[<?php echo esc_attr( $i ); ?>][has_colors]" class="sbp-has-colors" value="1" <?php checked( $has_colors, '1' ); ?>>
							<span class="sbp-chk-box"></span>
							<span>Colors available for this item?</span>
						</label>
						<div class="sbp-variant-body sbp-colors-wrap <?php echo $has_colors ? '' : 'sbp-hidden'; ?>">
							<div class="sbp-variant-title">Available Colors <small>— one per field</small></div>
							<div class="sbp-sub-rows sbp-color-rows">
								<?php foreach ( $colors as $col ) : ?>
								<div class="sbp-sub-row">
									<input type="text" name="sbp_items[<?php echo esc_attr( $i ); ?>][colors][]" class="sbp-input sbp-sub-input" value="<?php echo esc_attr( $col ); ?>" placeholder="e.g. Black">
									<button type="button" class="sbp-del-sub" title="Remove"><svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
								</div>
								<?php endforeach; ?>
							</div>
							<button type="button" class="sbp-add-sub sbp-add-color">+ Add Color</button>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php
	}

	public function save_meta( $post_id, $post ) {
		if ( ! isset( $_POST['sbp_nonce'] ) || ! wp_verify_nonce( $_POST['sbp_nonce'], 'sbp_save' ) ) { return; }
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) { return; }
		if ( ! current_user_can( 'edit_post', $post_id ) ) { return; }

		$enabled = isset( $_POST['sbp_bundle_enabled'] ) ? '1' : '';
		update_post_meta( $post_id, '_sbp_bundle_enabled', $enabled );

		$raw   = isset( $_POST['sbp_items'] ) ? (array) $_POST['sbp_items'] : array();
		$clean = array();

		foreach ( $raw as $item ) {
			$row = array(
				'image_id'   => absint( isset( $item['image_id'] )  ? $item['image_id']  : 0 ),
				'image_url'  => esc_url_raw( isset( $item['image_url'] ) ? $item['image_url'] : '' ),
				'title'      => sanitize_text_field( isset( $item['title'] ) ? $item['title'] : '' ),
				'desc'       => wp_kses_post( isset( $item['desc'] ) ? $item['desc'] : '' ),
				'has_sizes'  => isset( $item['has_sizes'] )  ? '1' : '',
				'has_colors' => isset( $item['has_colors'] ) ? '1' : '',
				'sizes'      => array(),
				'colors'     => array(),
			);

			if ( $row['has_sizes'] && ! empty( $item['sizes'] ) ) {
				foreach ( (array) $item['sizes'] as $sz ) {
					$sz = sanitize_text_field( $sz );
					if ( $sz !== '' ) { $row['sizes'][] = $sz; }
				}
			}
			if ( $row['has_colors'] && ! empty( $item['colors'] ) ) {
				foreach ( (array) $item['colors'] as $col ) {
					$col = sanitize_text_field( $col );
					if ( $col !== '' ) { $row['colors'][] = $col; }
				}
			}

			if ( $row['title'] !== '' ) { $clean[] = $row; }
		}

		update_post_meta( $post_id, '_sbp_bundle_items', $clean );
	}

	/* ------------------------------------------------------------------ */
	/*  Save bundle details with order                               */
	/* ------------------------------------------------------------------ */

	/**
	 * Attach bundle data to order line item during checkout.
	 */
	public function add_bundle_data_to_order_item( $item, $cart_item_key, $values, $order ) {
		$product_id = isset( $values['product_id'] ) ? absint( $values['product_id'] ) : 0;
		if ( ! $product_id ) { return; }

		$enabled = get_post_meta( $product_id, '_sbp_bundle_enabled', true );
		if ( ! $enabled ) { return; }

		$items = get_post_meta( $product_id, '_sbp_bundle_items', true );
		if ( ! is_array( $items ) || empty( $items ) ) { return; }

		// Store bundle items as JSON (hidden meta)
		$item->add_meta_data( '_sbp_bundle_items_json', wp_json_encode( $items ), true );

		// Add a human-readable summary visible to admin
		$summary_parts = array();
		foreach ( $items as $idx => $bundle_item ) {
			if ( empty( $bundle_item['title'] ) ) { continue; }
			$line = ( $idx + 1 ) . '. ' . $bundle_item['title'];
			if ( ! empty( $bundle_item['has_sizes'] ) && ! empty( $bundle_item['sizes'] ) ) {
				$line .= ' [Sizes: ' . implode( ', ', $bundle_item['sizes'] ) . ']';
			}
			if ( ! empty( $bundle_item['has_colors'] ) && ! empty( $bundle_item['colors'] ) ) {
				$line .= ' [Colors: ' . implode( ', ', $bundle_item['colors'] ) . ']';
			}
			$summary_parts[] = $line;
		}
		if ( ! empty( $summary_parts ) ) {
			$item->add_meta_data( 'Bundle Items', implode( ' | ', $summary_parts ), true );
		}
	}

	/**
	 * Display a clean label for Bundle Items meta key on admin order page.
	 */
	public function rename_order_meta_key( $display_key, $meta, $item ) {
		if ( 'Bundle Items' === $display_key ) {
			return __( '📦 Bundle Items', 'wc-bundle' );
		}
		return $display_key;
	}

	/**
	 * Hide raw JSON meta from admin display.
	 */
	public function hide_raw_bundle_meta( $hidden_metas ) {
		$hidden_metas[] = '_sbp_bundle_items_json';
		$hidden_metas[] = '_sbp_bundle_data_json';
		$hidden_metas[] = '_sbp_bundle_items';
		$hidden_metas[] = '_sbp_selections';
		return $hidden_metas;
	}

	/**
	 * Display bundle items in table format on admin order detail page.
	 */
	public function display_bundle_items_in_order( $item_id, $item, $product ) {
		// Only process order items
		if ( ! $item instanceof WC_Order_Item_Product ) { return; }

		$json = $item->get_meta( '_sbp_bundle_items_json' );
		if ( ! $json ) { return; }

		$bundle_items = json_decode( $json, true );
		if ( ! is_array( $bundle_items ) || empty( $bundle_items ) ) { return; }

		echo '<div class="sbp-order-bundle-wrap" style="margin-top:8px;padding:10px 12px;background:#f8f9fa;border-left:3px solid #f5a623;font-size:12px;">';
		echo '<strong style="display:block;margin-bottom:6px;color:#1d1d1d;">📦 Bundle Contents (' . count( $bundle_items ) . ' items)</strong>';
		echo '<table style="width:100%;border-collapse:collapse;">';
		echo '<thead><tr style="border-bottom:1px solid #e5e5e5;">';
		echo '<th style="text-align:left;padding:4px 6px;color:#666;font-weight:600;">#</th>';
		echo '<th style="text-align:left;padding:4px 6px;color:#666;font-weight:600;">Item</th>';
		echo '<th style="text-align:left;padding:4px 6px;color:#666;font-weight:600;">Sizes</th>';
		echo '<th style="text-align:left;padding:4px 6px;color:#666;font-weight:600;">Colors</th>';
		echo '</tr></thead>';
		echo '<tbody>';
		foreach ( $bundle_items as $idx => $bi ) {
			$title  = ! empty( $bi['title'] ) ? esc_html( $bi['title'] ) : '—';
			$sizes  = ( ! empty( $bi['has_sizes'] ) && ! empty( $bi['sizes'] ) ) ? esc_html( implode( ', ', $bi['sizes'] ) ) : '—';
			$colors = ( ! empty( $bi['has_colors'] ) && ! empty( $bi['colors'] ) ) ? esc_html( implode( ', ', $bi['colors'] ) ) : '—';
			echo '<tr style="border-bottom:1px solid #f0f0f0;">';
			echo '<td style="padding:4px 6px;color:#888;">' . ( $idx + 1 ) . '</td>';
			echo '<td style="padding:4px 6px;font-weight:600;color:#121212;">' . $title . '</td>';
			echo '<td style="padding:4px 6px;color:#555;">' . $sizes . '</td>';
			echo '<td style="padding:4px 6px;color:#555;">' . $colors . '</td>';
			echo '</tr>';
		}
		echo '</tbody></table>';
		echo '</div>';
	}
}
