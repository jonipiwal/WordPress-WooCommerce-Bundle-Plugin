/**
 * WooCommerce Bundle Plugin – Frontend JS v3.3
 *
 * Read More detection — bulletproof approach:
 *   - Get the LIVE clamped offsetHeight of the desc element
 *   - Temporarily force overflow:visible + max-height:none via inline style
 *   - Read the expanded offsetHeight
 *   - Restore original inline style
 *   - No cloning needed — avoids width calculation issues
 */
(function ($) {
	'use strict';

	$(document).ready(function () {

		/* Wait for fonts + layout to fully paint before measuring */
		setTimeout(initBundles, 300);

		/* Also catch late-loading themes (Elementor etc.) */
		$(window).on('load', function () {
			setTimeout(initBundles, 100);
		});

		var initialized = false;

		function initBundles() {
			if (initialized) { return; }
			initialized = true;

			$('.sbp-bundle-section .sbp-bundle-item').each(function () {
				var $item = $(this);
				var $info = $item.find('.sbp-bundle-info');
				var $desc = $item.find('.sbp-bundle-item-desc');
				var $btn  = $item.find('.sbp-read-more');

				/* Inject spacer before selects so selects stay at bottom */
				if ( ! $info.find('.sbp-info-spacer').length ) {
					var $selects = $info.find('.sbp-bundle-selects');
					if ( $selects.length ) {
						$('<div class="sbp-info-spacer"></div>').insertBefore($selects);
					} else {
						$info.append('<div class="sbp-info-spacer"></div>');
					}
				}

				if ( ! $desc.length || ! $btn.length ) { return; }

				checkReadMore($desc, $btn);

				$(window).on('resize.sbp', debounce(function () {
					if ( ! $desc.hasClass('sbp-desc-open') ) {
						checkReadMore($desc, $btn);
					}
				}, 250));

				$btn.on('click', function (e) {
					e.preventDefault();
					if ( $desc.hasClass('sbp-desc-open') ) {
						$desc.removeClass('sbp-desc-open');
						$(this).text('Read More');
					} else {
						$desc.addClass('sbp-desc-open');
						$(this).text('Read Less');
					}
				});
			});
		}

		/**
		 * checkReadMore — in-place expand/measure/collapse.
		 *
		 * Steps:
		 * 1. Record clamped height (offsetHeight with clamp active)
		 * 2. Apply inline override style to remove clamp
		 * 3. Record expanded height
		 * 4. Restore original inline style
		 * 5. If expanded > clamped → text was truncated → show button
		 *
		 * Why this works: operates on the LIVE element at correct width.
		 * No clone, no width guessing, no jQuery CSS key issues.
		 */
		function checkReadMore($desc, $btn) {
			var el = $desc[0];

			/* Step 1: clamped height */
			var clampedH = el.offsetHeight;

			/* Step 2: save current inline style, force-expand */
			var savedStyle = el.getAttribute('style') || '';
			el.setAttribute('style',
				savedStyle +
				';display:block!important;' +
				'-webkit-line-clamp:unset!important;' +
				'overflow:visible!important;' +
				'max-height:none!important;'
			);

			/* Step 3: expanded height — force reflow */
			var expandedH = el.offsetHeight;

			/* Step 4: restore */
			el.setAttribute('style', savedStyle);

			/* Step 5: decide */
			if (expandedH > clampedH + 2) {
				$btn.addClass('sbp-rm-visible');
			} else {
				$btn.removeClass('sbp-rm-visible');
			}
		}

		function debounce(fn, wait) {
			var timer;
			return function () {
				clearTimeout(timer);
				timer = setTimeout(fn, wait);
			};
		}

		/* ============================================================
		   COLLECT SIZE + COLOR → ADD TO CART
		   ============================================================ */
		function collectSelections() {
			var selections = [];
			$('.sbp-bundle-section .sbp-bundle-item').each(function (idx) {
				var $item = $(this);
				selections.push({
					index: idx,
					title: $item.find('.sbp-bundle-item-title').text().trim(),
					size:  $item.find('.sbp-select[aria-label="Select Size"]').val()  || '',
					color: $item.find('.sbp-select[aria-label="Select Color"]').val() || ''
				});
			});
			return selections;
		}

		$('form.cart').on('submit', function () {
			var $form = $(this);
			var sels  = collectSelections();
			if ( ! sels.length ) { return; }
			$form.find('.sbp-sel-field').remove();
			$('<input type="hidden" name="_sbp_selections_json">')
				.addClass('sbp-sel-field')
				.val(JSON.stringify(sels))
				.appendTo($form);
		});

		$(document.body).on('click', '.single_add_to_cart_button, .add_to_cart_button', function () {
			try {
				sessionStorage.setItem('sbp_last_selections', JSON.stringify(collectSelections()));
			} catch (e) {}
		});

	});

})(jQuery);
