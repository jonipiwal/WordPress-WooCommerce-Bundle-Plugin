/**
 * Setwear Bundle Plugin – Admin JS v2.0
 * Softbourne Technologies | https://softbourne.com
 *
 * Fixes:
 *  - Sizes/Colors: each value in its own field (no comma-separated)
 *  - Image: single-click upload (no double-trigger)
 *  - Rich editor: contenteditable synced to hidden input before save
 *  - Collapse/expand rows
 *  - Live item count badge
 */
(function ($) {
	'use strict';

	var $wrap, $builder, $itemsWrap;
	var itemIndex = 0;
	var mediaFrame = null;  // reuse one frame instance

	$(document).ready(function () {
		$wrap      = $('.sbp-wrap');
		if (!$wrap.length) return;
		$builder   = $('#sbp_bundle_builder');
		$itemsWrap = $('#sbp_items_wrap');
		itemIndex  = $itemsWrap.find('.sbp-item-row').length;

		initToggle();
		initAddItem();
		initItemsWrap();
		initSortable();
		initEditors();
		initFormSubmit();
	});

	/* ── Toggle ── */
	function initToggle() {
		$('#sbp_bundle_enabled').on('change', function () {
			var on = $(this).is(':checked');
			$('#sbp_switch_label').text(on ? 'Enabled' : 'Disabled');
			$builder.toggleClass('sbp-hidden', !on);
			$('#sbp_disabled_notice').toggleClass('sbp-hidden', on);
		});
	}

	/* ── Add item ── */
	function initAddItem() {
		$('#sbp_add_item, .sbp-add-item-alias').on('click', addItem);
	}
	function addItem() {
		var tpl = $('#sbp_item_template').html();
		var html = tpl.replace(/__INDEX__/g, itemIndex);
		var $row = $(html);
		$row.find('.sbp-item-num').text(itemIndex + 1);
		$itemsWrap.append($row);
		itemIndex++;
		updateCount();
		// Bind events on new row
		initEditors($row);
	}

	/* ── Events delegated on items wrap ── */
	function initItemsWrap() {
		// Remove item
		$itemsWrap.on('click', '.sbp-remove-item', function () {
			if (!confirm('Remove this bundle item?')) return;
			$(this).closest('.sbp-item-row').remove();
			updateCount();
			renumberItems();
		});

		// Collapse / expand
		$itemsWrap.on('click', '.sbp-collapse-row', function () {
			var $btn = $(this);
			var $body = $btn.closest('.sbp-item-row').find('.sbp-row-body');
			$body.slideToggle(180);
			$btn.toggleClass('is-collapsed');
		});

		// Has-sizes toggle
		$itemsWrap.on('change', '.sbp-has-sizes', function () {
			$(this).closest('.sbp-variant-col').find('.sbp-sizes-wrap')
				.toggleClass('sbp-hidden', !$(this).is(':checked'));
		});

		// Has-colors toggle
		$itemsWrap.on('change', '.sbp-has-colors', function () {
			$(this).closest('.sbp-variant-col').find('.sbp-colors-wrap')
				.toggleClass('sbp-hidden', !$(this).is(':checked'));
		});

		// Add size
		$itemsWrap.on('click', '.sbp-add-size', function () {
			addSubRow($(this).closest('.sbp-variant-col').find('.sbp-size-rows'), 'sizes', $(this));
		});

		// Add color
		$itemsWrap.on('click', '.sbp-add-color', function () {
			addSubRow($(this).closest('.sbp-variant-col').find('.sbp-color-rows'), 'colors', $(this));
		});

		// Remove sub-row
		$itemsWrap.on('click', '.sbp-del-sub', function () {
			var $rows = $(this).closest('.sbp-sub-rows');
			if ($rows.find('.sbp-sub-row').length > 1) {
				$(this).closest('.sbp-sub-row').remove();
			} else {
				$(this).closest('.sbp-sub-row').find('input').val('');
			}
		});

		// Image: choose (single binding via delegation)
		$itemsWrap.on('click', '.sbp-choose-image', function (e) {
			e.preventDefault();
			e.stopPropagation();
			var $btn   = $(this);
			var $zone  = $btn.closest('.sbp-img-zone');
			openMediaPicker($zone);
		});

		// Image: remove
		$itemsWrap.on('click', '.sbp-img-remove', function (e) {
			e.preventDefault();
			var $zone = $(this).closest('.sbp-img-zone');
			$zone.find('.sbp-image-id').val('');
			$zone.find('.sbp-image-url').val('');
			$zone.find('.sbp-img-thumb').html(
				'<div class="sbp-img-empty"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" opacity=".35"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg></div>'
			);
			$zone.find('.sbp-img-btn').text('Upload Image');
			$zone.removeClass('has-img');
			$(this).remove();
		});

		// Title: update preview in header
		$itemsWrap.on('input', '.sbp-title-input', function () {
			var val = $(this).val();
			$(this).closest('.sbp-item-row').find('.sbp-row-preview').html(
				val ? escHtml(val.substring(0, 50)) : '<em>Untitled item</em>'
			);
		});
	}

	/* ── Sub row add ── */
	function addSubRow($rows, type, $addBtn) {
		// Derive name from existing inputs; fallback to item index
		var existingName = $rows.find('input').first().attr('name') || '';
		var baseName = existingName ? existingName.replace(/\[\d+\]$/, '').replace(/\[\]$/, '') : '';
		if (!baseName) {
			var idx = $addBtn.closest('.sbp-item-row').data('index');
			baseName = 'sbp_items[' + idx + '][' + type + ']';
		}
		var $row = $(
			'<div class="sbp-sub-row">' +
			'<input type="text" name="' + baseName + '[]" class="sbp-input sbp-sub-input" placeholder="' + (type === 'sizes' ? 'e.g. M' : 'e.g. Red') + '">' +
			'<button type="button" class="sbp-del-sub" title="Remove">' +
			'<svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>' +
			'</button></div>'
		);
		$rows.append($row);
		$row.find('input').focus();
	}

	/* ── Media picker (one frame, no double-open) ── */
	function openMediaPicker($zone) {
		// If frame already open, reuse
		if (mediaFrame) {
			// Re-wire select for THIS zone
			mediaFrame.off('select');
			mediaFrame.on('select', function () {
				handleMediaSelect(mediaFrame, $zone);
			});
			mediaFrame.open();
			return;
		}
		mediaFrame = wp.media({
			title   : SBP.chooseImage,
			button  : { text: SBP.useImage },
			multiple: false,
			library : { type: 'image' }
		});
		mediaFrame.on('select', function () {
			handleMediaSelect(mediaFrame, $zone);
		});
		mediaFrame.open();
	}

	function handleMediaSelect(frame, $zone) {
		var att = frame.state().get('selection').first().toJSON();
		var url  = (att.sizes && att.sizes.thumbnail) ? att.sizes.thumbnail.url : att.url;
		$zone.find('.sbp-image-id').val(att.id);
		$zone.find('.sbp-image-url').val(att.url);
		$zone.find('.sbp-img-thumb').html('<img src="' + url + '" alt="" style="width:100%;height:100%;object-fit:cover;display:block;">');
		$zone.find('.sbp-img-btn').text('Change Image');
		$zone.addClass('has-img');
		if (!$zone.find('.sbp-img-remove').length) {
			$zone.find('.sbp-img-btn').after('<button type="button" class="sbp-img-remove">Remove</button>');
		}
	}

	/* ── Rich editor: sync contenteditable → hidden input ── */
	function initEditors($ctx) {
		$ctx = $ctx || $(document);
		$ctx.find('.sbp-rich-editor').each(function () {
			var $ed = $(this);
			var $hidden = $ed.closest('.sbp-editor-wrap').parent().find('.sbp-desc-hidden');
			// Use mutation observer OR input event
			$ed.on('input paste keyup', function () {
				$hidden.val($ed.html());
			});
		});
		// Formatting buttons (delegated to body for new rows)
		if ($ctx.is($(document))) {
			$('body').on('click', '.sbp-fmt', function (e) {
				e.preventDefault();
				var cmd = $(this).data('cmd');
				var val = $(this).data('val') || null;
				document.execCommand(cmd, false, val);
				// Sync
				var $ed = $(document.activeElement);
				if ($ed.hasClass('sbp-rich-editor')) {
					$ed.closest('.sbp-editor-wrap').parent().find('.sbp-desc-hidden').val($ed.html());
				}
			});
		}
	}

	/* ── Sync all editors on form submit ── */
	function initFormSubmit() {
		$('#post').on('submit', function () {
			$('.sbp-rich-editor').each(function () {
				var $ed     = $(this);
				var $hidden = $ed.closest('.sbp-editor-wrap').parent().find('.sbp-desc-hidden');
				$hidden.val($ed.html());
			});
		});
	}

	/* ── Sortable ── */
	function initSortable() {
		$itemsWrap.sortable({
			handle     : '.sbp-drag-handle',
			placeholder: 'sbp-item-row ui-sortable-placeholder',
			tolerance  : 'pointer',
			update     : renumberItems
		});
	}

	/* ── Helpers ── */
	function updateCount() {
		$('#sbp_item_count').text($itemsWrap.find('.sbp-item-row').length);
	}
	function renumberItems() {
		$itemsWrap.find('.sbp-item-row').each(function (i) {
			$(this).find('.sbp-item-num').first().text(i + 1);
		});
		updateCount();
	}
	function escHtml(s) {
		return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
	}

})(jQuery);
